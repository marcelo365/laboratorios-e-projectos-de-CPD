#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "gestor.h"

_Bool procurar_tarefa(tarefa *lista, char *nome_tarefa)
{
    while (lista != NULL)
    {
        if (strcmp(nome_tarefa, lista->nome_tarefa) == 0)
        {
            return 1;
        }
        lista = lista->next;
    }
    return 0;
}

void inserir_tarefa(tarefa **lista, char *nome_tarefa, int prioridade)
{

    if (procurar_tarefa(*lista, nome_tarefa))
    {
        printf("\nTAREFA JÁ INSERIDA\n");
        return;
    }

    tarefa *nova_tarefa = (tarefa *)malloc(sizeof(tarefa));
    if (nova_tarefa != NULL)
    {
        nova_tarefa->nome_tarefa = strdup(nome_tarefa);
        nova_tarefa->prioridade = prioridade;

        if (*lista == NULL)
        {
            nova_tarefa->next = *lista;
            *lista = nova_tarefa;
            return;
        }

        tarefa *aux = *lista;
        tarefa *tarefa_anterior = NULL;

        while (aux != NULL)
        {
            if (prioridade >= aux->prioridade)
            {
                if (tarefa_anterior != NULL)
                {
                    tarefa_anterior->next = nova_tarefa;
                    nova_tarefa->next = aux;
                }
                else
                {
                    nova_tarefa->next = aux;
                    *lista = nova_tarefa;
                }
                return;
            }
            tarefa_anterior = aux;
            aux = aux->next;
        }

        tarefa_anterior->next = nova_tarefa;
        nova_tarefa->next = NULL;
    }
    else
    {
        printf("Erro ao alocar memória\n");
        exit(1);
    }
}

void imprimir_tarefas(tarefa *lista)
{

    while (lista != NULL)
    {
        printf("ID : %s | Prioridade : %d\n", lista->nome_tarefa, lista->prioridade);
        lista = lista->next;
    }
}

void listar_tarefas_com_prioridade_indicada(tarefa *lista, int prioridade)
{
    while (lista != NULL)
    {
        if (lista->prioridade >= prioridade)
        {
            printf("ID : %s | Prioridade : %d\n", lista->nome_tarefa, lista->prioridade);
        }
        lista = lista->next;
    }
}

void remover_tarefa(tarefa **lista, char *nome_tarefa)
{
    tarefa *tarefa_anterior = NULL;
    tarefa *aux = *lista;

    while (aux != NULL)
    {
        if (strcmp(nome_tarefa, aux->nome_tarefa) == 0)
        {
            if (tarefa_anterior != NULL)
            {
                tarefa_anterior->next = aux->next;
            }
            else
            {
                *lista = (*lista)->next;
            }
            free(aux);
            return;
        }
        tarefa_anterior = aux;
        aux = aux->next;
    }

    printf("\nTAREFA INEXISTENTE\n");
}

int readLineArguments(char **argVector, int vectorSize, char *buffer, int buffersize)
{
    int numtokens = 0;
    char *s = " \r\n\t";

    int i;

    char *token;

    if (argVector == NULL || buffer == NULL || vectorSize <= 0 || buffersize <= 0)
        return 0;

    if (fgets(buffer, buffersize, stdin) == NULL)
    {
        return -1;
    }

    /* get the first token */
    token = strtok(buffer, s);

    /* walk through other tokens */
    while (numtokens < vectorSize - 1 && token != NULL)
    {
        argVector[numtokens] = token;
        numtokens++;

        token = strtok(NULL, s);
    }

    for (i = numtokens; i < vectorSize; i++)
    {
        argVector[i] = NULL;
    }

    return numtokens;
}
